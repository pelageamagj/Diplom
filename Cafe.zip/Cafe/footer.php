<!-- footer.php -->
<footer class="mt-5">
    <div class="container text-center">
        <p class="mb-1">© <?php echo date("Y"); ?> Кис Кис Клаб — котокафе для души</p>
        <p class="small">Сделано с любовью к котикам 🐱</p>
    </div>
</footer>
