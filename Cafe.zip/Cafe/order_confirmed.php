<?php
session_start();
include 'connect.php'; // Подключаем соединение с базой данных

// Проверка, что корзина пуста (заказ оформлен)
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: index.php'); // Если корзина пуста, перенаправляем на главную
    exit;
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Заказ оформлен — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<div class="container mt-5 text-center">
    <h2>Спасибо за заказ!</h2>
    <p>Ваш заказ успешно оформлен. Мы скоро свяжемся с вами для подтверждения.</p>
    <a href="profile.php" class="btn btn-primary mt-3">Перейти в личный кабинет</a>
    <a href="index.php" class="btn btn-secondary mt-3">На главную</a>
</div>

<?php include 'footer.php'; ?>

</body>
</html>
