<?php
// booking_confirmation.php
session_start();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Подтверждение бронирования — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center">
        <h1 class="display-4">Спасибо за бронирование!</h1>
        <p class="lead">Ваше бронирование успешно оформлено. Мы с нетерпением ждем вашего визита!</p>
        <p>Наши сотрудники скоро свяжутся с вами для подтверждения.</p>
        <a href="index.php" class="btn btn-primary mt-3">Вернуться на главную</a>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
