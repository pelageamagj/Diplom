<?php
session_start();
include 'connect.php'; // Подключаем соединение с базой данных

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $user_id = $_SESSION['user_id'];  // Получаем ID пользователя из сессии
    $total_price = 0;

    // Проходим по всем товарам в корзине
    foreach ($_SESSION['cart'] as $item) {
        // Записываем каждый товар в заказ
        $service_id = $item['id']; // Идентификатор услуги
        $price = $item['price'];   // Цена услуги
        $total_price += $price;    // Суммируем стоимость товаров

        // Вставляем товар в таблицу заказов
        $sql = "INSERT INTO bookings (user_id, service_id, status, booking_date) 
                VALUES (?, ?, 'новый', NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $user_id, $service_id);
        if ($stmt->execute()) {
            echo "Заказ добавлен в базу данных."; // Это поможет проверить, добавляется ли заказ
        } else {
            echo "Ошибка добавления заказа.";  // Это поможет выявить ошибку
        }
    }

    // Очистка корзины после оформления заказа
    $_SESSION['cart'] = [];

    // Перенаправление на страницу подтверждения заказа
    header('Location: order_confirmed.php');
    exit;
} else {
    echo "Корзина пуста!";
}
?>
