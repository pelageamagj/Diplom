<!-- header.php -->
<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php" style="color: #d9827f;">
            🐾 Кис Кис Клаб
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Главная</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="sale.php">Меню и услуги</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cats.php">Котики</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="booking_form.php">Бронирование</a>
                    <a href="cart.php" class="btn btn-outline-dark">
                      🛒 Корзина
                         <?php
                            $count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
                            if ($count > 0) echo " ($count)";
                            ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="donate.php">Донат</a>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- Личный кабинет -->
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Личный кабинет</a>
                    </li>
                    <!-- Админ панель (доступна только администраторам) -->
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php">Админ панель</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link text-danger" href="logout.php">Выход</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Вход</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Регистрация</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
