<?php
// sale.php
session_start();
include 'connect.php';

// Получаем выбранные фильтры
$menu_category = $_GET['menu_category'] ?? '';
$service_category = $_GET['service_category'] ?? '';

// Получаем меню и услуги с учётом фильтра
$menu = getMenu($menu_category);
$services = getServices($service_category);

// Функции
function getMenu($category = '') {
    global $conn;
    $sql = "SELECT * FROM menu";
    if ($category !== '') {
        $sql .= " WHERE category = '" . $conn->real_escape_string($category) . "'";
    }
    return $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
}

function getServices($category = '') {
    global $conn;
    $sql = "SELECT * FROM services";
    if ($category !== '') {
        $sql .= " WHERE category = '" . $conn->real_escape_string($category) . "'";
    }
    return $conn->query($sql)->fetch_all(MYSQLI_ASSOC);
}

// Для выпадающих списков
$menuCategories = $conn->query("SELECT DISTINCT category FROM menu")->fetch_all(MYSQLI_ASSOC);
$serviceCategories = $conn->query("SELECT DISTINCT category FROM services")->fetch_all(MYSQLI_ASSOC);

// Функция для добавления товара в корзину
function addToCart($productId, $type) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Проверяем, если товар уже есть в корзине
    if ($type === 'menu') {
        $productTable = 'menu';
    } elseif ($type === 'service') {
        $productTable = 'services';
    }

    global $conn;
    $sql = "SELECT * FROM $productTable WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if ($product) {
        $productId = $product['id'];
        // Если товар уже есть в корзине, увеличиваем его количество
        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId]['quantity']++;
        } else {
            $_SESSION['cart'][$productId] = [
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => 1
            ];
        }
    }
}

// Проверяем, если был запрос на добавление товара в корзину
if (isset($_GET['add_to_cart'])) {
    $productId = $_GET['add_to_cart'];
    $type = $_GET['type'];
    addToCart($productId, $type);
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Меню и Услуги — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Наше меню</h1>
        <p class="lead">Попробуйте вкусности с мурлыками!</p>
    </div>

    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-6">
            <select name="menu_category" class="form-select" onchange="this.form.submit()">
                <option value="">Все категории меню</option>
                <?php foreach ($menuCategories as $cat): ?>
                    <option value="<?= $cat['category'] ?>" <?= $cat['category'] == $menu_category ? 'selected' : '' ?>>
                        <?= $cat['category'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-6">
            <select name="service_category" class="form-select" onchange="this.form.submit()">
                <option value="">Все категории услуг</option>
                <?php foreach ($serviceCategories as $cat): ?>
                    <option value="<?= $cat['category'] ?>" <?= $cat['category'] == $service_category ? 'selected' : '' ?>>
                        <?= $cat['category'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <!-- Блюда -->
    <div class="row g-4 mb-5">
        <?php if (count($menu) > 0): ?>
            <?php foreach ($menu as $item): ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?= $item['image'] ?>" class="card-img-top" alt="<?= $item['name'] ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= $item['name'] ?></h5>
                            <p class="card-text"><?= $item['description'] ?></p>
                            <p><strong>Цена: <?= $item['price'] ?> руб.</strong></p>
                            <a href="sale.php?add_to_cart=<?= $item['id'] ?>&type=menu" class="btn btn-outline-primary">В корзину</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Нет блюд в этой категории.</p>
        <?php endif; ?>
    </div>

    <!-- Услуги -->
    <div class="text-center mb-4">
        <h1 class="display-4">Наши услуги</h1>
        <p class="lead">Выберите услугу для бронирования</p>
    </div>

    <div class="row g-4">
        <?php if (count($services) > 0): ?>
            <?php foreach ($services as $service): ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?= $service['image'] ?>" class="card-img-top" alt="<?= $service['name'] ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= $service['name'] ?></h5>
                            <p class="card-text"><?= $service['description'] ?></p>
                            <p><strong>Цена: <?= $service['price'] ?> руб.</strong></p>
                            <a href="sale.php?add_to_cart=<?= $service['id'] ?>&type=service" class="btn btn-outline-primary">В корзину</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Нет услуг в этой категории.</p>
        <?php endif; ?>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
