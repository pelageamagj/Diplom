<?php
// cats.php
session_start();
include 'connect.php';

// Получаем все котиков из базы данных
$sql = "SELECT * FROM cats";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Наши котики — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Наши котики</h1>
        <p class="lead">Познакомьтесь с пушистыми друзьями, которые обитают в нашем котокафе!</p>
    </div>

    <div class="row g-4">
        <?php
        if ($result->num_rows > 0) {
            // Выводим каждого котика
            while ($cat = $result->fetch_assoc()) {
                echo '
                <div class="col-md-4">
                    <div class="card shadow-sm h-100">
                        <img src="' . $cat['image'] . '" class="card-img-top" alt="' . $cat['name'] . '">
                        <div class="card-body">
                            <h5 class="card-title">' . $cat['name'] . '</h5>
                            <p class="card-text"><strong>Возраст:</strong> ' . $cat['age'] . ' лет</p>
                            <p class="card-text"><strong>Описание:</strong> ' . $cat['description'] . '</p>
                        </div>
                    </div>
                </div>
                ';
            }
        } else {
            echo '<p class="text-center">Котики не найдены.</p>';
        }
        ?>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
