<?php
session_start();
include 'connect.php'; // Подключаем соединение с базой данных

// Проверка, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php'); // Перенаправляем на страницу логина, если пользователь не администратор
    exit;
}

$user_id = $_SESSION['user_id']; // Получаем ID пользователя из сессии

// Получаем информацию о пользователе
$sql_user = "SELECT * FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user = $result_user->fetch_assoc();

// Получаем все заказы
$sql_orders = "SELECT b.id, b.booking_date, b.status, s.name AS service_name, s.price, u.first_name, u.last_name
               FROM bookings b
               JOIN services s ON b.service_id = s.id
               JOIN users u ON b.user_id = u.id
               ORDER BY b.booking_date DESC";

$stmt_orders = $conn->prepare($sql_orders);
$stmt_orders->execute();
$result_orders = $stmt_orders->get_result();

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Админ панель — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Админ панель</h1>
        <p class="lead">Добро пожаловать в панель управления. Здесь вы можете управлять пользователями и заказами.</p>
    </div>

    <!-- Информация о пользователе -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Информация о пользователе</h5>
            <p><strong>Имя:</strong> <?= htmlspecialchars($user['first_name']) ?> <?= htmlspecialchars($user['last_name']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            <p><strong>Телефон:</strong> <?= htmlspecialchars($user['phone']) ?></p>
            <p><strong>Роль:</strong> Администратор</p>
            <a href="edit_user.php?user_id=<?= $user['id'] ?>" class="btn btn-primary">Редактировать профиль</a>
        </div>
    </div>

    <!-- Список заказов -->
    <div class="mb-4">
        <h5>Все заказы</h5>
        <?php if ($result_orders->num_rows > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Дата заказа</th>
                        <th>Пользователь</th>
                        <th>Товар</th>
                        <th>Цена</th>
                        <th>Статус</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = $result_orders->fetch_assoc()): ?>
                        <tr>
                            <td><?= date('d.m.Y H:i', strtotime($order['booking_date'])) ?></td>
                            <td><?= htmlspecialchars($order['first_name']) ?> <?= htmlspecialchars($order['last_name']) ?></td>
                            <td><?= htmlspecialchars($order['service_name']) ?></td>
                            <td><?= $order['price'] ?> руб.</td>
                            <td><?= htmlspecialchars($order['status']) ?></td>
                            <td>
                                <!-- Кнопка для подтверждения заказа -->
                                <?php if ($order['status'] != 'подтверждено'): ?>
                                    <a href="confirm_order.php?order_id=<?= $order['id'] ?>" class="btn btn-success btn-sm">Подтвердить</a>
                                <?php endif; ?>
                                <!-- Кнопка для отмены заказа -->
                                <a href="cancel_order.php?order_id=<?= $order['id'] ?>" class="btn btn-danger btn-sm">Отменить</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Нет заказов для отображения.</p>
        <?php endif; ?>
    </div>

</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
