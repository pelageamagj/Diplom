<?php
// booking_form.php
session_start();
include 'connect.php';

// Получаем информацию о выбранной услуге
if (isset($_GET['service_id'])) {
    $service_id = $_GET['service_id'];
    $stmt = $conn->prepare("SELECT * FROM services WHERE id = ?");
    $stmt->bind_param("i", $service_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $service = $result->fetch_assoc();
} else {
    header("Location: sale.php"); // Если параметр отсутствует, редирект на страницу услуг
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Бронирование — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Бронирование услуги: <?= htmlspecialchars($service['name']) ?></h1>
        <p class="lead"><?= htmlspecialchars($service['description']) ?></p>
        <p><strong>Цена: <?= htmlspecialchars($service['price']) ?> руб.</strong></p>
    </div>

    <form action="process_booking.php" method="POST">
        <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
        <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">

        <div class="form-group">
            <label for="booking_date">Дата и время:</label>
            <input type="datetime-local" class="form-control" id="booking_date" name="booking_date" required>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Забронировать</button>
    </form>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
