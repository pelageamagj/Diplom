<?php
// logout.php
session_start();

// Уничтожаем все сессионные переменные
session_unset();

// Уничтожаем сессию
session_destroy();

// Перенаправляем на главную страницу или страницу логина
header('Location: index.php');  // или header('Location: login.php');
exit;
?>
