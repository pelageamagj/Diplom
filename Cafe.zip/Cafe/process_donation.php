<?php
// process_donation.php
session_start();
include 'connect.php';

// Проверяем, что данные пришли из формы
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $amount = $_POST['amount'];
    $comment = $_POST['comment'] ?? null; // Если комментарий пуст, то null

    // Вставка доната в таблицу donations
    $stmt = $conn->prepare("INSERT INTO donations (user_id, amount, comment) VALUES (?, ?, ?)");
    $stmt->bind_param("ids", $user_id, $amount, $comment);
    $stmt->execute();
    $stmt->close();

    // Перенаправление на страницу подтверждения доната
    header("Location: donation_confirmation.php");
    exit();
}
?>
