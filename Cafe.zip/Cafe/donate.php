<?php
// donate.php
session_start();
include 'connect.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Если не авторизован, перенаправляем на страницу входа
    exit();
}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Сделать донат — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Сделать донат</h1>
        <p class="lead">Спасибо за ваше желание помочь! Ваши пожертвования идут на помощь нашим пушистым друзьям и развитие котокафе.</p>
    </div>

    <form action="process_donation.php" method="POST">
        <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?>">

        <div class="form-group">
            <label for="amount">Сумма доната (руб.):</label>
            <input type="number" class="form-control" id="amount" name="amount" required min="1" step="0.01">
        </div>

        <div class="form-group mt-3">
            <label for="comment">Комментарий (опционально):</label>
            <textarea class="form-control" id="comment" name="comment" rows="4"></textarea>
        </div>

        <button type="submit" class="btn btn-danger mt-3">Подтвердить донат</button>
    </form>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
