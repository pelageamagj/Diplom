<?php
session_start();
include 'connect.php'; // Подключаем соединение с базой данных

// Проверка прав администратора
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    // Обновляем статус заказа на 'отменено'
    $sql = "UPDATE bookings SET status = 'отменено' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();

    // Перенаправление обратно на админ-панель
    header('Location: admin_dashboard.php');
    exit;
} else {
    echo "Неверный ID заказа!";
}
?>
