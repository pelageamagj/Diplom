<?php
// register.php
session_start();
include 'connect.php';

// Обработка формы регистрации
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $last_name = $_POST['last_name'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Защищаем от SQL инъекций
    $last_name = $conn->real_escape_string($last_name);
    $first_name = $conn->real_escape_string($first_name);
    $middle_name = $conn->real_escape_string($middle_name);
    $phone = $conn->real_escape_string($phone);
    $email = $conn->real_escape_string($email);
    $password = $conn->real_escape_string($password);
    
    // Проверка, существует ли уже пользователь с таким email
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $error = "Пользователь с таким email уже существует.";
    } else {
        // Хешируем пароль
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Вставляем данные в таблицу пользователей
        $sql = "INSERT INTO users (last_name, first_name, middle_name, phone, email, password, role, status) 
                VALUES ('$last_name', '$first_name', '$middle_name', '$phone', '$email', '$hashed_password', 'user', 'active')";

        if ($conn->query($sql) === TRUE) {
            // Если регистрация прошла успешно, авторизуем пользователя и перенаправляем
            $_SESSION['user_id'] = $conn->insert_id; // Получаем id последнего вставленного пользователя
            $_SESSION['email'] = $email;
            $_SESSION['role'] = 'user';

            header('Location: profile.php');
            exit;
        } else {
            $error = "Ошибка при регистрации: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Регистрация</h1>
    </div>

    <!-- Форма регистрации -->
    <div class="card">
        <div class="card-body">
            <?php if (isset($error)) { echo "<div class='alert alert-danger'>$error</div>"; } ?>
            <form action="register.php" method="POST">
                <div class="mb-3">
                    <label for="last_name" class="form-label">Фамилия</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                </div>
                <div class="mb-3">
                    <label for="first_name" class="form-label">Имя</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                </div>
                <div class="mb-3">
                    <label for="middle_name" class="form-label">Отчество</label>
                    <input type="text" class="form-control" id="middle_name" name="middle_name" required>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Телефон</label>
                    <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Электронная почта</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Подтвердите пароль</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Зарегистрироваться</button>
            </form>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
