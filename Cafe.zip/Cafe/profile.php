<?php
// profile.php
session_start();
include 'connect.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Получаем данные текущего пользователя
$user_id = $_SESSION['user_id'];
$sql_user = "SELECT * FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user = $result_user->fetch_assoc();

// Запрос на получение заказов
$sql_orders = "SELECT b.id, b.booking_date, b.status, s.name AS service_name, s.price
               FROM bookings b
               JOIN services s ON b.service_id = s.id
               WHERE b.user_id = ?
               ORDER BY b.booking_date DESC";

$stmt_orders = $conn->prepare($sql_orders);
$stmt_orders->bind_param("i", $user_id);
$stmt_orders->execute();
$result_orders = $stmt_orders->get_result();

// Добавляем отладочные выводы
if ($result_orders->num_rows > 0) {
    echo "<pre>";
    var_dump($result_orders->fetch_all(MYSQLI_ASSOC));  // Показываем все данные из результата запроса
    echo "</pre>";
} else {
    echo "Нет заказов для отображения.";
}
// Проверка роли
$is_admin = ($user['role'] == 'admin');
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Профиль — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Мой профиль</h1>
        <p class="lead">Здесь вы можете редактировать свои данные и просматривать историю заказов.</p>
    </div>

    <!-- Информация о пользователе -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Информация о пользователе</h5>
            <p><strong>Имя:</strong> <?= htmlspecialchars($user['first_name']) ?> <?= htmlspecialchars($user['last_name']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            <p><strong>Телефон:</strong> <?= htmlspecialchars($user['phone']) ?></p>
            <p><strong>Роль:</strong> <?= $user['role'] == 'admin' ? 'Администратор' : 'Пользователь' ?></p>

            <?php if ($is_admin): ?>
                <a href="edit_user.php?user_id=<?= $user['id'] ?>" class="btn btn-primary">Редактировать профиль</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- История заказов -->
    <div class="mb-4">
        <h5>Мои заказы</h5>
        <?php if ($result_orders->num_rows > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Дата заказа</th>
                        <th>Услуга</th>
                        <th>Количество</th>
                        <th>Цена</th>
                        <th>Статус</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($order = $result_orders->fetch_assoc()): ?>
                        <tr>
                            <td><?= date('d.m.Y H:i', strtotime($order['booking_date'])) ?></td>
                            <td><?= htmlspecialchars($order['service_name']) ?></td>
                            <td>1</td>
                            <td><?= $order['price'] ?> руб.</td>
                            <td><?= htmlspecialchars($order['status']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>У вас пока нет заказов.</p>
        <?php endif; ?>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
