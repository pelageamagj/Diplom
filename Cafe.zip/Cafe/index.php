<?php
// index.php
session_start();
include 'connect.php';

// Обработка отправки отзыва
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_review'])) {
    if (isset($_SESSION['user_id']) && !empty($_POST['review_text'])) {
        $user_id = $_SESSION['user_id'];
        $review_text = $_POST['review_text'];

        $sql = "INSERT INTO reviews (user_id, review_text) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $user_id, $review_text);
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Ваш отзыв был успешно отправлен!</div>";
        } else {
            echo "<div class='alert alert-danger'>Ошибка при отправке отзыва.</div>";
        }
    } else {
        echo "<div class='alert alert-warning'>Пожалуйста, войдите в систему и напишите отзыв.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Кис Кис Клаб — Котокафе</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet"> 
</head>
<body>
<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Добро пожаловать в Кис Кис Клаб!</h1>
        <p class="lead">Уютное пространство, где вы можете отдохнуть с пушистыми друзьями, выпить кофе и сделать доброе дело.</p>
    </div>

    <div class="row text-center mb-5">
        <div class="col-md-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title">Наше кафе</h5>
                    <p class="card-text">
                        📍 Адрес: г. Котоград, ул. Мурлыкина, 12<br>
                        ☎ Телефон: +7 (999) 123-45-67<br>
                        ✉ Email: info@kisskissclub.ru
                    </p>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <img src="img/cafe.jpg" class="img-fluid rounded shadow" alt="Интерьер котокафе">
        </div>
    </div>

    <div class="row g-4 text-center">
        <div class="col-md-3">
            <a href="booking_form.php" class="btn btn-outline-primary w-100 py-3">Забронировать время</a>
        </div>
        <div class="col-md-3">
            <a href="sale.php" class="btn btn-outline-success w-100 py-3">Меню и услуги</a>
        </div>
        <div class="col-md-3">
            <a href="cats.php" class="btn btn-outline-warning w-100 py-3">Наши котики</a>
        </div>
        <div class="col-md-3">
            <a href="donate.php" class="btn btn-outline-danger w-100 py-3">Сделать донат</a>
        </div>
    </div>

    <!-- Форма для отзыва -->
    <div class="card mt-5">
        <div class="card-body">
            <h5 class="card-title">Оставить отзыв</h5>
            <form method="POST">
                <div class="mb-3">
                    <textarea class="form-control" name="review_text" rows="4" placeholder="Напишите свой отзыв здесь..." required></textarea>
                </div>
                <button type="submit" name="submit_review" class="btn btn-primary">Отправить отзыв</button>
            </form>
        </div>
    </div>

    <!-- Список отзывов -->
    <h3 class="mt-5">Отзывы</h3>
    <?php
    // Получаем все отзывы из базы данных
    $sql_reviews = "SELECT r.review_text, r.created_at, u.first_name, u.last_name 
                    FROM reviews r
                    JOIN users u ON r.user_id = u.id
                    ORDER BY r.created_at DESC";
    $result_reviews = $conn->query($sql_reviews);

    if ($result_reviews->num_rows > 0) {
        while ($review = $result_reviews->fetch_assoc()) {
            echo "<div class='card mb-3'>
                    <div class='card-body'>
                        <h5 class='card-title'>" . htmlspecialchars($review['first_name']) . " " . htmlspecialchars($review['last_name']) . "</h5>
                        <p class='card-text'>" . nl2br(htmlspecialchars($review['review_text'])) . "</p>
                        <p class='text-muted'>" . date('d.m.Y H:i', strtotime($review['created_at'])) . "</p>
                    </div>
                </div>";
        }
    } else {
        echo "<p>Пока нет отзывов.</p>";
    }
    ?>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
