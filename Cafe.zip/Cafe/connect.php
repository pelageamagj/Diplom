<?php
// connect.php

$servername = "localhost"; // Адрес сервера MySQL
$username = "root"; // Имя пользователя для подключения
$password = ""; // Пароль пользователя (пустой для локальной базы данных)
$dbname = "Cafe"; // Имя базы данных

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}
?>
