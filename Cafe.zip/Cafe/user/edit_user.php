<?php
// edit_user.php
session_start();
include 'connect.php';

// Проверка, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php'); // Перенаправление на страницу логина, если не администратор
    exit;
}

// Получаем user_id из URL
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
} else {
    header('Location: profile.php'); // Если user_id не передан, перенаправляем на профиль
    exit;
}

// Получаем данные пользователя для редактирования
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Если пользователь не найден
    echo "Пользователь не найден.";
    exit;
}

$user = $result->fetch_assoc();

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];

    // Обновляем данные пользователя в базе
    $sql_update = "UPDATE users SET 
                    first_name = '$first_name', 
                    last_name = '$last_name', 
                    phone = '$phone', 
                    role = '$role' 
                   WHERE id = $user_id";

    if ($conn->query($sql_update) === TRUE) {
        echo "Данные пользователя успешно обновлены.";
    } else {
        echo "Ошибка при обновлении данных: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактировать пользователя — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Редактирование профиля пользователя</h1>
    </div>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Информация о пользователе</h5>
            <form action="edit_user.php?user_id=<?= $user['id'] ?>" method="POST">
                <div class="mb-3">
                    <label for="first_name" class="form-label">Имя</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="last_name" class="form-label">Фамилия</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Телефон</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="role" class="form-label">Роль</label>
                    <select class="form-select" id="role" name="role" required>
                        <option value="user" <?= $user['role'] == 'user' ? 'selected' : '' ?>>Пользователь</option>
                        <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>Администратор</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Сохранить изменения</button>
            </form>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
