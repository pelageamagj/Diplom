<?php
session_start();
include 'connect.php';

$type = $_GET['type'] ?? '';
$id = (int)($_GET['id'] ?? 0);

// Проверка валидности
if (!in_array($type, ['menu', 'service']) || $id <= 0) {
    header('Location: sale.php');
    exit;
}

// Получение данных о товаре
$table = $type === 'menu' ? 'menu' : 'services';
$sql = "SELECT * FROM $table WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $item = $result->fetch_assoc();

    // Создание корзины, если она пуста
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Уникальный ключ: menu_1, service_3 и т.д.
    $key = $type . '_' . $id;

    if (!isset($_SESSION['cart'][$key])) {
        $_SESSION['cart'][$key] = [
            'type' => $type,
            'id' => $id,
            'name' => $item['name'],
            'price' => $item['price'],
            'qty' => 1
        ];
    } else {
        $_SESSION['cart'][$key]['qty']++;
    }
}

header('Location: cart.php');
exit;
