<?php
session_start();
include 'connect.php';

// Получаем корзину из сессии
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];

// Если корзина пуста
if (empty($cart)) {
    $message = "Ваша корзина пуста.";
} else {
    $message = null;
}

// Функция для подсчета общей суммы
function getTotal($cart) {
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    return $total;
}

// Удаление товара из корзины
if (isset($_GET['remove'])) {
    $productId = $_GET['remove'];
    if (isset($cart[$productId])) {
        unset($cart[$productId]);
        $_SESSION['cart'] = $cart;
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Корзина — Кис Кис Клаб</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<?php include 'header.php'; ?>

<section class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4">Ваша корзина</h1>
        <p class="lead">Вы можете оформить заказ или продолжить покупки</p>
    </div>

    <?php if ($message): ?>
        <div class="alert alert-warning"><?= $message ?></div>
    <?php endif; ?>

    <?php if (!empty($cart)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Товар</th>
                    <th>Цена</th>
                    <th>Количество</th>
                    <th>Итого</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cart as $id => $item): ?>
                    <tr>
                        <td><?= $item['name'] ?></td>
                        <td><?= $item['price'] ?> руб.</td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= $item['price'] * $item['quantity'] ?> руб.</td>
                        <td>
                            <a href="cart.php?remove=<?= $id ?>" class="btn btn-danger btn-sm">Удалить</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="text-end">
            <h3>Общая сумма: <?= getTotal($cart) ?> руб.</h3>
        </div>

        <div class="text-center mt-4">
            <a href="checkout.php" class="btn btn-primary">Оформить заказ</a>
            <a href="sale.php" class="btn btn-outline-secondary">Продолжить покупки</a>
        </div>
    <?php endif; ?>
</section>

<?php include 'footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
