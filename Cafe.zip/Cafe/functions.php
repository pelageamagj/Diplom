// functions.php
<?php
// Функция для добавления товара в корзину
function addToCart($productId, $quantity = 1) {
    // Начинаем сессию, если она еще не началась
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = []; // Инициализируем корзину
    }

    // Проверяем, если товар уже есть в корзине
    if (isset($_SESSION['cart'][$productId])) {
        // Если товар уже есть в корзине, увеличиваем его количество
        $_SESSION['cart'][$productId] += $quantity;
    } else {
        // Если товара нет, добавляем его в корзину
        $_SESSION['cart'][$productId] = $quantity;
    }
}
?>