<?php
// process_booking.php
session_start();
include 'connect.php';

// Проверяем, что данные пришли из формы
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $service_id = $_POST['service_id'];
    $booking_date = $_POST['booking_date'];

    // Вставка нового бронирования в таблицу
    $stmt = $conn->prepare("INSERT INTO bookings (user_id, service_id, booking_date, status) VALUES (?, ?, ?, 'новый')");
    $stmt->bind_param("iis", $user_id, $service_id, $booking_date);
    $stmt->execute();
    $stmt->close();

    // Перенаправление на страницу подтверждения бронирования
    header("Location: booking_confirmation.php");
    exit();
}
?>
