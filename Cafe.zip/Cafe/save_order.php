// save_order.php
<?php
session_start();
include 'connect.php'; // подключение к базе данных

// Проверяем, есть ли корзина в сессии
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php'); // Если корзина пуста, редиректим в корзину
    exit();
}

$user_id = $_SESSION['user_id'];  // Получаем ID пользователя из сессии
$cart = $_SESSION['cart'];  // Получаем товары из корзины

// Функция для подсчета общей суммы заказа
function getTotal($cart) {
    $total = 0;
    foreach ($cart as $item) {
        $total += $item['quantity'] * $item['price'];
    }
    return $total;
}

$total_price = getTotal($cart); // Получаем общую сумму

// Сохраняем заказ в таблицу orders
$stmt = $conn->prepare("INSERT INTO orders (user_id, total_price) VALUES (?, ?)");
$stmt->bind_param("id", $user_id, $total_price);
$stmt->execute();
$order_id = $conn->insert_id;  // Получаем ID нового заказа

// Сохраняем товары из корзины в таблицу order_items
foreach ($cart as $item) {
    $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
    $stmt->execute();
}

// Очищаем корзину после оформления заказа
unset($_SESSION['cart']);

header('Location: profile.php');  // Перенаправляем пользователя в личный кабинет
exit();
?>